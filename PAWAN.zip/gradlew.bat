@echo off
rem Gradle wrapper execution script for Windows
gradle %*
