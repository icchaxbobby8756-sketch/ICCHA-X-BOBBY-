# ICCHA X BOBBY Android App

Official Android Application source code for **ICCHA X BOBBY**.

## 🚀 How to Build the Real APK Online on Your Android Phone:

1. **Upload to GitHub**:
   - On your phone browser (Chrome), open [GitHub.com](https://github.com)
   - Tap **New Repository** -> name it `iccha-x-bobby-android`
   - Upload this project ZIP or push the files.

2. **Trigger the Cloud Build**:
   - Go to the **Actions** tab on your phone.
   - Tap **Build ICCHA X BOBBY Android APK** -> **Run workflow**.

3. **Download Your Real APK**:
   - In ~2 minutes, the run will finish with a green checkmark!
   - Tap the run, scroll to **Artifacts**, and tap **ICCHA_X_BOBBY-APK** to download your real `app-release.apk` / `app-debug.apk`!
   - Open and tap **Install** on your phone!
